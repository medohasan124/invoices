<?php
use Illuminate\Database\Seeder;
use App\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
class CreateAdminUserSeeder extends Seeder
{
/**
* Run the database seeds.
*
* @return void
*/
public function run()
{

 $role = Role::create(['name' => 'Admin']);
 $permissions = Permission::pluck('id','id')->all();
 $role->syncPermissions($permissions);


$user = User::create([
'name' => 'medo',
'email' => 'medo@yahoo.com',
'member' => 1,
'status' => 'active',

'password' => bcrypt('123123123')
]);

$user->assignRole([$role->id]);


}
}