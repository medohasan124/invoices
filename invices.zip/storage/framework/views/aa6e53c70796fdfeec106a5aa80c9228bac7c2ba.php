<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>

<button>click</button>
<script src="<?php echo e(URL::asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/sweetalert.min.js')); ?>"></script>

<script>
	//import swal from 'sweetalert';
//swal("Hello world!");

$('button').click(function(){
	swal({
  text: 'Search for a movie. e.g. "La La Land".',
  button: {
    text: "Search!",
    closeModal: false,
  },
}).then(name => {
  
  name = 'hh' ;
 
  return name ;
}).then(results => {
  return results ;
})
// 	.then((value) => {

// 	 $.ajax({
//                 type:'get',
//                 url:'<?php echo e(url('admin/testing')); ?>',
//                 data:{_token: "<?php echo e(csrf_token()); ?>"
//                 },
//                 success: function( msg ) {
//                 	value = msg ;
//                 }
//             });
              



//   swal(`The returned value is: ${value}`);


// }
// )

});
</script>
</body>
</html><?php /**PATH D:\xampp\htdocs\invices\resources\views/admin/invoice/test.blade.php ENDPATH**/ ?>