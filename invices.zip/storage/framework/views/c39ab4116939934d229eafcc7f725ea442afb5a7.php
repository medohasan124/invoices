

<?php $__env->startSection('css'); ?>
<!-- Internal Data table css -->
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/datatable/css/responsive.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
<!-- Modal effects -->
		<div class="modal effect-scale " id="modaldemo7">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content modal-content-demo">
					<div class="modal-header">
						<h6 class="modal-title"><?php echo e(trans('admin.create')); ?></h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="modal-body" style='background: #dfe1e4'>
						
						<br>
						<?php echo e(Form::open(['method' => 'post' , 'route' => 'section.store'])); ?>

						
						<?php echo e(Form::label(trans('admin.section_name'))); ?>

						<?php echo e(Form::text('name' , null, ['class' => 'form-control' ,"autocomplete"=>"off" ,'id' => 'section_name'])); ?>

						
						<br>
						<?php echo e(Form::label(trans('admin.section_disc'))); ?>

						<?php echo e(Form::textarea('description' ,null, ['class' => 'form-control','autocomplete'=>"off" ,'id' => 'section_disc'])); ?>

					</div>

						<div class="modal-footer">

						<button class=" btn  btn-success create_section"><?php echo e(trans('admin.sure')); ?></button>
						
						<button class="btn ripple btn-secondary " data-dismiss="modal" type="button"><?php echo e(trans('admin.close')); ?></button>
						<?php echo e(Form::close()); ?>

						</div>
						<!--end single footer button-->
					</div>
				</div>
			</div>



					<div class="modal effect-scale " id="modaldemo9">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content modal-content-demo">
					<div class="modal-header">
						<h6 class="modal-title"><?php echo e(trans('admin.create')); ?></h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="modal-body" style='background: #dfe1e4'>
						
						<br>
						<?php echo e(Form::open(['method' => 'PUT' , 'url' => 'admin/section'])); ?>

						
						<?php echo e(Form::label(trans('admin.section_name'))); ?>

						<?php echo e(Form::text('name' , null, ['class' => 'form-control' ,"autocomplete"=>"off" ,'id' => 'section_name'])); ?>

						
						<br>
						<?php echo e(Form::label(trans('admin.section_disc'))); ?>

						<?php echo e(Form::textarea('description' ,null, ['class' => 'form-control','autocomplete'=>"off" ,'id' => 'section_disc'])); ?>

					</div>

						<div class="modal-footer">

						<button class=" btn  btn-success" style='cursor:pointer'><?php echo e(trans('admin.sure')); ?></button>
						
						<button class="btn ripple btn-secondary " data-dismiss="modal" type="button"><?php echo e(trans('admin.close')); ?></button>
						<?php echo e(Form::close()); ?>

						</div>
						<!--end single footer button-->
					</div>
				</div>
			</div>
		</div>
		<!-- End Modal effects-->

		<!-- Modal effects -->
		<div class="modal effect-scale " id="modaldemo8">
			<div class="modal-dialog modal-dialog-centered" role="document">
				<div class="modal-content modal-content-demo">
					<div class="modal-header">
						<h6 class="modal-title"><?php echo e(trans('admin.alert')); ?></h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="modal-body">
						<h6><?php echo e(trans('admin.alert')); ?></h6>
						<p class='select_all_delete'><?php echo e(trans('admin.please_select')); ?></p>
					</div>
					<div class="modal-footer">
						<button class="btn ripple btn-danger modal_delete d-none" type="button"><?php echo e(trans('admin.delete')); ?></button>

						<!--start single footer button-->
						<div class='d-none single_modal_delete'>
						<?php echo e(Form::open(['method' => 'delete' , 'url' => 'admin/section/destroy'])); ?>

						
						<?php echo e(Form::hidden('id' , null, ['class' => 'single-delete'])); ?>

						<?php echo e(Form::submit(trans('admin.delete') , ['class' => ' btn  btn-danger'])); ?>

						<?php echo e(Form::close()); ?>

						</div>
						<!--end single footer button-->

						<button class="btn ripple btn-secondary " data-dismiss="modal" type="button"><?php echo e(trans('admin.close')); ?></button>
					</div>

					

					
				</div>
			</div>
		</div>
		<!-- End Modal effects-->


				<!-- breadcrumb -->
				<div class="breadcrumb-header justify-content-between">
					<div class="my-auto">
						<div class="d-flex">
							<h4 class="content-title mb-0 my-auto"><?php echo e(trans('admin.sections')); ?></h4>
						</div>
					</div>
					<div class="d-flex my-xl-auto right-content">
						<div class="pr-1 mb-3 mb-xl-0">
							<button type="button" class="btn btn-info btn-icon ml-2"><i class="mdi mdi-filter-variant"></i></button>
						</div>
						<div class="pr-1 mb-3 mb-xl-0">
							<button type="button" class="btn btn-danger btn-icon ml-2"><i class="mdi mdi-star"></i></button>
						</div>
						<div class="pr-1 mb-3 mb-xl-0">
							<button type="button" class="btn btn-warning  btn-icon ml-2"><i class="mdi mdi-refresh"></i></button>
						</div>
						<div class="mb-3 mb-xl-0">
							<div class="btn-group dropdown">
								<button type="button" class="btn btn-primary">14 Aug 2019</button>
								<button type="button" class="btn btn-primary dropdown-toggle dropdown-toggle-split" id="dropdownMenuDate" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								<span class="sr-only">Toggle Dropdown</span>
								</button>
								<div class="dropdown-menu dropdown-menu-left" aria-labelledby="dropdownMenuDate" data-x-placement="bottom-end">
									<a class="dropdown-item" href="#">2015</a>
									<a class="dropdown-item" href="#">2016</a>
									<a class="dropdown-item" href="#">2017</a>
									<a class="dropdown-item" href="#">2018</a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
				<!-- row opened -->
				<div class="row row-sm">

					<!--div-->
					<div class="col-xl-12">
						<div class="card mg-b-20">
							<div class="card-header pb-0">

 <?php if(session()->get('success')): ?>

<div class="alert alert-success" role="alert">
    <button aria-label="Close" class="close" data-dismiss="alert" type="button">
	   <span aria-hidden="true">&times;</span>
  </button>
    <?php echo e(session()->get('success')); ?>

</div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
     
      	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="alert alert-danger mg-b-0" role="alert">
				<button aria-label="Close" class="close" data-dismiss="alert" type="button">
					<span aria-hidden="true">&times;</span>
				</button>
				<?php echo e($err); ?>

			</div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    <?php endif; ?>
								<div class="d-flex justify-content-between">

									<h4 class="card-title mg-b-0"><?php echo e(trans('admin.sections')); ?></h4>
									<i class="mdi mdi-dots-horizontal text-gray"></i>
								</div>
								
							</div>
							<div class="card-body">
								<div class="table-responsive">
										<?php echo e(Form::open(['id' =>'del' ,'method' => 'delete' , 'url' => 'admin/section/destroy'])); ?>

									<table id="example" class="table key-buttons text-md-nowrap text-center">
										<thead>
											<tr>
												<th class="border-bottom-0">#</th>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-delete')): ?>
												<th class="border-bottom-0">
												<?php echo e(trans('admin.select_all')); ?>

												<input type='checkbox' class='deleteAll' value='0'></td>
												<?php endif; ?>
											</th>
												
												<th class="border-bottom-0"><?php echo e(trans('admin.section')); ?></th>
												<th class="border-bottom-0"><?php echo e(trans('admin.discription')); ?></th>
												
												<th class="border-bottom-0"><?php echo e(trans('admin.addBy')); ?></th>
												
												<th class="border-bottom-0"><?php echo e(trans('admin.created_at')); ?></th>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-edit')): ?>
												<th class="border-bottom-0"><?php echo e(trans('admin.update')); ?></th>
												<?php endif; ?>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-delete')): ?>
												<th class="border-bottom-0"><?php echo e(trans('admin.delete')); ?></th>
												<?php endif; ?>
											</tr>
										</thead>
										<tbody>

								


											<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
												<td><?php echo e($row->id); ?></td>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-delete')): ?>
												<td><input type='checkbox' value='<?php echo e($row->id); ?>' name='del[]' class='check_delete' ></td>
												<?php endif; ?>
												
												<td><?php echo e($row->name); ?></td>
												<td><?php echo e($row->description); ?></td>
												<td><?php echo e($row->addBy); ?></td>
												<td><?php echo e($row->created_at); ?></td>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-edit')): ?>
												<td><a href="#" class='btn btn-success edit_section' id='<?php echo e($row->id); ?>' data-name='<?php echo e($row->name); ?>' data-discrption='<?php echo e($row->description); ?>'><i class='fas fa-edit '></i></a></td>
												<?php endif; ?>
												<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-delete')): ?>
												<td><a data-name='<?php echo e($row->name); ?>' href="#" id='<?php echo e($row->id); ?>' class='btn btn-danger modal-effect delete_one' data-target='#modaldemo8' data-toggle="modal"><i class='fas fa-trash  ' data-effect="effect-scale" ></i></a></td>
												<?php endif; ?>
												
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
										</tbody>
									</table>
									<?php echo e(Form::close()); ?>

								</div>
							</div>
						</div>
					</div>
					<!--/div-->

					
				</div>
				<!-- /row -->
			</div>
			<!-- Container closed -->
		</div>
		<!-- main-content closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Internal Data tables -->
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/responsive.dataTables.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('assets/plugins/datatable/js/responsive.bootstrap4.min.js')); ?>"></script>
<!--Internal  Datatable js -->
<script src="<?php echo e(URL::asset('assets/js/table-data.js')); ?>"></script>

<script>
	//file export datatable
	var table = $('#example').DataTable({
		"ordering": false,
		lengthChange: false,
		buttons: [
		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-create')): ?>
		{extend:'', text:'Create <i class="fas fa-plus"></i>' , className:'btn btn-danger create_button'},
		<?php endif; ?>
		{extend:'copy', text:'Copy <i class="fas fa-file"></i>' , className:'btn btn-success'},
		{extend:'csv', text:'CSV <i class="fas fa-file"></i>', className:'btn btn-info'},
		{extend:'excel', text:'Excel <i class="fas fa-file"></i>', className:'btn btn-primary'},
		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('section-delete')): ?>
		{extend:'', text:'<i class="fas fa-trash"></i>', className:'btn btn-danger deleteAllButton modal-effect'},
		<?php endif; ?>
		],
		responsive: true,
		language: {
			searchPlaceholder: 'Search...',
			sSearch: '',
			lengthMenu: '_MENU_ ',
		}
	});


	table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
	// add data to delete button
	$('.deleteAllButton').attr('data-toggle' ,'modal');
	$('.deleteAllButton').attr('data-target' ,'#modaldemo8');
	$('.deleteAllButton').attr('data-effect' ,'effect-scale');

	// add data to delete button
	$('.create_button').attr('data-toggle' ,'modal');
	$('.create_button').attr('data-target' ,'#modaldemo7');
	$('.create_button').attr('data-effect' ,'effect-scale');

	// add data to edit button
	$('.edit_section').attr('data-toggle' ,'modal');
	$('.edit_section').attr('data-target' ,'#modaldemo9');
	$('.edit_section').attr('data-effect' ,'effect-scale');



	
	$('.deleteAll').change(function(){
		 $('table .check_delete').prop('checked' , $(this).prop('checked'));

		 var x    = $('table .check_delete:checked').length ;
	 if(x > 0){
	 	$('.modal p').html('<?php echo e(trans("admin.last_delete")); ?>' + x);
	 	$('.modal_delete').removeClass('d-none');
	 }else{
	 	$('.modal p').html('<?php echo e(trans("admin.please_select")); ?>');
	 	$('.modal_delete').addClass('d-none');
	 	
	 }

	});



	//if you click to select single checkbox
	$('.check_delete').click(function(){
		$('.single_modal_delete').addClass('d-none');
    var x    = $('table .check_delete:checked').length ;
	 if(x > 0){
	 	$('.modal p').html('<?php echo e(trans("admin.last_delete")); ?>' + x);
	 	$('.modal_delete').removeClass('d-none');
	 }else{
	 	$('.modal p').html('<?php echo e(trans("admin.please_select")); ?>');
	 	$('.modal_delete').addClass('d-none');
	 	
	 }

	 if(x == $('.check_delete').length){
	 	 $('.deleteAll').prop('checked' , true);
	 }else{
	 	$('.deleteAll').prop('checked' ,false);
	 }
	});



	$('.deleteAllButton').click(function(){

	$('.select_all_delete').html('<?php echo e(trans('admin.please_select')); ?>');
		$('.single_modal_delete').addClass('d-none');
		var x    = $('table .check_delete:checked').length ;
		 if(x > 0){
	 	$('.modal p').html('<?php echo e(trans("admin.last_delete")); ?>' + x);
	 	$('.modal_delete').removeClass('d-none');
	 }else{
	 	$('.modal p').html('<?php echo e(trans("admin.please_select")); ?>');
	 	$('.modal_delete').addClass('d-none');
	 	
	 }
	});

	//single modal delete
	$('.modal_delete').click(function(){
		
		$('#del').submit();
	});

	 $(document).on('click', 'table .delete_one',function(){
	 	$('.modal_delete').addClass('d-none');
	 	$('.single_modal_delete').removeClass('d-none');
	 	var id = $(this).attr('id');
	 	var name = $(this).attr('data-name');
	 	$('.single-delete').val(id);

	 	$('#modaldemo8 p').html('<?php echo e(trans("admin.sure_delete")); ?>' + name);
	 	console.log(name);
	 	
	 });
	/*end delete All*/	




	/*start edit section*/
	$('.edit_section').click(function(){

		var id 			= $(this).attr('id');
		var name 		= $(this).attr('data-name');
		var discription = $(this).attr('data-discrption');

		$('#modaldemo9 #section_name').val(name);
		$('#modaldemo9 #section_disc').html(discription);
		$('#modaldemo9 form').attr('action' , '<?php echo e(url("admin/section")); ?>/'+id);
		console.log(name);
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\invices\resources\views/admin/invoice/section.blade.php ENDPATH**/ ?>